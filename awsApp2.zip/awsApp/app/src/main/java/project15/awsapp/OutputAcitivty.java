package project15.awsapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class OutputAcitivty extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.output_display);

        Intent update = getIntent();
        Bundle b = update.getExtras();
        EditText editText1 = (EditText) findViewById(R.id.textOutputView);
        if (b != null) {
            String j = (String) b.get("mytext");
            editText1.setText(j);
        }
    }
}

